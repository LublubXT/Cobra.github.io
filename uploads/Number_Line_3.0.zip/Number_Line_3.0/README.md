# Number_Line_1.0

## How to run 
To run the app go to the files and open the .exe file and wait for it to upload.

## Warning
There are a few bugs with the program like you can put a operator in first unless it is a negative otherwise it wont work and you will get an error in the code.
We will try to fix these problems in the next version.

## Photos
![Screenshot (15)](https://user-images.githubusercontent.com/73581388/97417013-db564500-190f-11eb-90af-9dd184deb918.png)

![Screenshot (16)](https://user-images.githubusercontent.com/73581388/97417174-0c367a00-1910-11eb-8739-22027f268ec9.png)

![Screenshot (17)](https://user-images.githubusercontent.com/73581388/97417233-16587880-1910-11eb-98f2-8002287e70ae.png)
